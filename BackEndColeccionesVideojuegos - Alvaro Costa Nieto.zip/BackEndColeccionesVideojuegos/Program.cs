using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Swashbuckle.AspNetCore.SwaggerGen;
using ColeccionesVideojuegos.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddSingleton<UsuarioService>();
builder.Services.AddSingleton<VideojuegoService>();
builder.Services.AddSingleton<ColeccionService>();

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();


if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(); // Acceso visual desde /swagger
}


app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers(); // Activa los controladores por atributos [Route]

app.Run();
