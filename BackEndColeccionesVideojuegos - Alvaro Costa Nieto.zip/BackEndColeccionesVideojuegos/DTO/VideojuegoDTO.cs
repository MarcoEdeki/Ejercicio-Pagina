namespace ColeccionesVideojuegos.DTO
{
    public class VideojuegoDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public List<string> Plataformas { get; set; }
        public string ImagenUrl { get; set; }
        public string CapturaUrl { get; set; }
        public DateTime FechaLanzamiento { get; set; }
    }

}