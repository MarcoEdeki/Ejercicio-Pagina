using ColeccionesVideojuegos.Models;
namespace ColeccionesVideojuegos.DTO
{
    public class CrearColeccionDTO
    {
        public int UsuarioId { get; set; }
        public List<Videojuego> Videojuegos { get; set; }
    }
}