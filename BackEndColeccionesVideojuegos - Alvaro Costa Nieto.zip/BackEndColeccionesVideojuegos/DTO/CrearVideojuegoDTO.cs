namespace ColeccionesVideojuegos.DTO
{
    public class CrearVideojuegoDTO
    {
        public string Nombre { get; set; }
        public string Descripcion { get; set; }
        public string ImagenUrl { get; set; }
        public string CapturaUrl { get; set; }
        public List<string> Plataformas { get; set; }
        public DateTime FechaLanzamiento { get; set; }
    }

}