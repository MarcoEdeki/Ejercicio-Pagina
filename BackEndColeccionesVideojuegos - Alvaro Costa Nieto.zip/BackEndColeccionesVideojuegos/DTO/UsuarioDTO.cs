using ColeccionesVideojuegos.Models;

namespace ColeccionesVideojuegos.DTO
{

    public class UsuarioDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; } 
        public string Email { get; set; } 
        public Coleccion ColeccionCreada { get; set; }
    }

}