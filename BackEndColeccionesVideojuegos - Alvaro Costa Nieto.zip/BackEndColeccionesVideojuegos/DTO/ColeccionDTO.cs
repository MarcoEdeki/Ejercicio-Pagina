using ColeccionesVideojuegos.Models;
namespace ColeccionesVideojuegos.DTO
{
    public class ColeccionDTO
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public List<Videojuego> Videojuegos { get; set; }
    }
}