using Microsoft.AspNetCore.Mvc;
using ColeccionesVideojuegos.Services;
using ColeccionesVideojuegos.DTO;
using System.Text.Json;

namespace ColeccionesVideojuegos.Controllers
{
    [ApiController]
    [Route("api/videojuego")]
    public class VideojuegoController : ControllerBase
    {
        private static VideojuegoService _servicio = new VideojuegoService();

        [HttpGet]
        public ActionResult<List<VideojuegoDTO>> ObtenerTodos()
        {
            List<VideojuegoDTO> juegos = _servicio.ObtenerTodos();
            return Ok(juegos);
        }

        [HttpGet("{id}")]
        public ActionResult<VideojuegoDTO> ObtenerPorId(int id)
        {
            VideojuegoDTO? juego = _servicio.ObtenerPorId(id);

            if (juego == null)
            {
                return NotFound();
            }
            return Ok(juego);
        }

        [HttpPost]
        public ActionResult<VideojuegoDTO> Crear([FromBody] CrearVideojuegoDTO nuevo)
        {
            VideojuegoDTO creado = _servicio.Crear(nuevo);
            return CreatedAtAction(nameof(ObtenerPorId), new { id = creado.Id }, creado);
        }

        [HttpPut("{id}")]
        public ActionResult Actualizar(int id, [FromBody] CrearVideojuegoDTO actualizado)
        {
            bool ok = _servicio.Actualizar(id, actualizado);

            if (!ok)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult Eliminar(int id)
        {
            bool ok = _servicio.Eliminar(id);

            if (!ok)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpGet("{plataforma}")]
        public ActionResult<List<VideojuegoDTO>> JuegosPlataforma(string plataforma)
        {
            List<VideojuegoDTO> juegos = _servicio.JuegosPlataforma(plataforma);
            return Ok(juegos);
        }
    }
}