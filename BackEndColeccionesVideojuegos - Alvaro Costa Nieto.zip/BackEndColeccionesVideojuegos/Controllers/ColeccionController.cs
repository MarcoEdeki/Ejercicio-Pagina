using Microsoft.AspNetCore.Mvc;
using ColeccionesVideojuegos.Services;
using ColeccionesVideojuegos.DTO;
using System.Text.Json;

namespace ColeccionesVideojuegos.Controllers
{
    [ApiController]
    [Route("api/coleccion")]
    public class ColeccionController : ControllerBase
    {
        private static ColeccionService _servicio = new ColeccionService();

        [HttpGet]
        public ActionResult<List<ColeccionDTO>> ObtenerTodas()
        {
            List<ColeccionDTO> colecciones = _servicio.ObtenerTodas();
            return Ok(colecciones);
        }

        [HttpPost]
        public ActionResult<ColeccionDTO> Crear([FromBody] CrearColeccionDTO nueva)
        {
            ColeccionDTO? creada = _servicio.Crear(nueva);

            if (creada == null)
            {
                return BadRequest();
            }
            return CreatedAtAction(nameof(ObtenerTodas), null, creada);
        }

        [HttpPut]
        public ActionResult<ColeccionDTO> AgregarJuegos([FromBody] CrearColeccionDTO nuevosJuegos)
        {
            ColeccionDTO? creada = _servicio.AgregarJuegos(nuevosJuegos);

            if (creada == null)
            {
                return BadRequest();
            }
            return NoContent();
        }

        [HttpGet("usuario/{id}")]
        public ActionResult<ColeccionDTO> ObtenerPorUsuario(int id)
        {
            ColeccionDTO colecciones = _servicio.ObtenerPorUsuario(id);
            return Ok(colecciones);
        }

        [HttpDelete("{id}")]
        public ActionResult Eliminar(int id)
        {
            bool ok = _servicio.Eliminar(id);

            if (!ok)
            {
                return NotFound();
            }
            return NoContent();
        }
    }
}