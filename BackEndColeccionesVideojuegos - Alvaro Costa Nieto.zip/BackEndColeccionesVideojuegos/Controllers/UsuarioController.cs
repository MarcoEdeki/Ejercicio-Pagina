using Microsoft.AspNetCore.Mvc;
using ColeccionesVideojuegos.Services;
using ColeccionesVideojuegos.DTO;
using System.Text.Json;

namespace ColeccionesVideojuegos.Controllers
{
    [ApiController]
    [Route("api/usuario")]
    public class UsuarioController : ControllerBase
    {
        private static UsuarioService _servicio = new UsuarioService();

        [HttpGet]
        public ActionResult<List<UsuarioDTO>> ObtenerTodos()
        {
            List<UsuarioDTO> usuarios = _servicio.ObtenerTodos();
            return Ok(usuarios);
        }

        [HttpGet("{id}")]
        public ActionResult<UsuarioDTO> ObtenerPorId(int id)
        {
            UsuarioDTO? usuario = _servicio.ObtenerPorId(id);

            if (usuario == null)
            {
                return NotFound();
            }

            return Ok(usuario);
        }

        [HttpPost]
        public ActionResult<UsuarioDTO> Crear([FromBody] CrearUsuarioDTO nuevoUsuario)
        {
            UsuarioDTO creado = _servicio.Crear(nuevoUsuario);
            return CreatedAtAction(nameof(ObtenerPorId), new { id = creado.Id }, creado);
        }

        [HttpPut("{id}")]
        public ActionResult Actualizar(int id, [FromBody] CrearUsuarioDTO datosActualizados)
        {
            bool actualizado = _servicio.Actualizar(id, datosActualizados);

            if (!actualizado)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpDelete("{id}")]
        public ActionResult Eliminar(int id)
        {
            bool eliminado = _servicio.Eliminar(id);

            if (!eliminado)
            {
                return NotFound();
            }
            return NoContent();
        }

        [HttpPost("login")]
        public ActionResult<UsuarioDTO> Login([FromBody] JsonElement datosLogin)
        {
            UsuarioDTO? usuario = _servicio.Login(datosLogin);

            if (usuario == null)
            {
                return Unauthorized();
            }
            return Ok(usuario);
        }
    }
}