namespace ColeccionesVideojuegos.Models
{
    public class Coleccion
    {
        public int Id { get; set; }
        public int UsuarioId { get; set; }
        public List<Videojuego> Videojuegos { get; set; }
    }
}