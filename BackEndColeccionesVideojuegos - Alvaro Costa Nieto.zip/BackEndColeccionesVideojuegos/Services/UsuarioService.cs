using ColeccionesVideojuegos.Models;
using ColeccionesVideojuegos.DTO;
using System.Text.Json;

namespace ColeccionesVideojuegos.Services
{
    public class UsuarioService
    {
        private static List<Usuario> _usuarios = new List<Usuario>();
        private static int _idActual = 1;

        public List<UsuarioDTO> ObtenerTodos()
        {
            List<UsuarioDTO> lista = new List<UsuarioDTO>();

            foreach (var user in _usuarios)
            {
                UsuarioDTO dto = new UsuarioDTO
                {
                    Id = user.Id,
                    Nombre = user.Nombre,
                    Email = user.Email,
                    ColeccionCreada = user.ColeccionCreada
                };
                lista.Add(dto);
            }

            return lista;
        }

        public UsuarioDTO? ObtenerPorId(int id)
        {
            foreach (var user in _usuarios)
            {
                if (user.Id == id)
                {
                    return new UsuarioDTO
                    {
                        Id = user.Id,
                        Nombre = user.Nombre,
                        Email = user.Email,
                        ColeccionCreada = user.ColeccionCreada
                    };
                }
            }

            return null;
        }

        public UsuarioDTO Crear(CrearUsuarioDTO nuevoUsuario)
        {
            Usuario usuario = new Usuario
            {
                Id = _idActual++,
                Nombre = nuevoUsuario.Nombre,
                Email = nuevoUsuario.Email,
                Contrasena = nuevoUsuario.Contrasena
            };

            _usuarios.Add(usuario);

            return new UsuarioDTO
            {
                Id = usuario.Id,
                Nombre = usuario.Nombre,
                Email = usuario.Email,
                ColeccionCreada = new Coleccion()
            };
        }
        
        public bool Actualizar(int id, CrearUsuarioDTO datosActualizados)
        {
            foreach (var usuario in _usuarios)
            {
                if (usuario.Id == id)
                {
                    usuario.Nombre = datosActualizados.Nombre;
                    usuario.Email = datosActualizados.Email;
                    usuario.Contrasena = datosActualizados.Contrasena;
                    return true;
                }
            }

            return false;
        }
        
        public bool Eliminar(int id)
        {
            for (int i = 0; i < _usuarios.Count; i++)
            {
                if (_usuarios[i].Id == id)
                {
                    _usuarios.RemoveAt(i);
                    return true;
                }
            }

            return false;
        }
        
        
        public UsuarioDTO? Login(JsonElement json)
        {
            string email = "";
            string contrasena = "";
            
            if (json.TryGetProperty("email", out JsonElement emailElement))
            {
                email = emailElement.GetString();
            }

            if (json.TryGetProperty("contrasena", out JsonElement contrasenaElement))
            {
                contrasena = contrasenaElement.GetString();
            }
            
            if (email == null || email == "" || contrasena == null || contrasena == "")
            {
                return null;
            }

            foreach (Usuario u in _usuarios)
            {
                if (u.Email == email && u.Contrasena == contrasena)
                {
                    UsuarioDTO dto = new UsuarioDTO();
                    dto.Id = u.Id;
                    dto.Nombre = u.Nombre;
                    dto.Email = u.Email;
                    dto.ColeccionCreada = u.ColeccionCreada;
                    return dto;
                }
            }
            
            return null;
        }
    }
}