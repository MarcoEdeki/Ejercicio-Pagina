using ColeccionesVideojuegos.Models;
using ColeccionesVideojuegos.DTO;
using System.Text.Json;

namespace ColeccionesVideojuegos.Services
{
    public class ColeccionService
    {
        private static List<Coleccion> _colecciones = new List<Coleccion>();
        private static int _idActual = 1;

        private static UsuarioService _usuarioService = new UsuarioService();
        private static VideojuegoService _videojuegoService = new VideojuegoService();

        public List<ColeccionDTO> ObtenerTodas()
        {
            List<ColeccionDTO> lista = new List<ColeccionDTO>();

            foreach (Coleccion c in _colecciones)
            {
                ColeccionDTO dto = new ColeccionDTO();
                dto.Id = c.Id;
                dto.UsuarioId = c.UsuarioId;
                dto.Videojuegos = c.Videojuegos;
                lista.Add(dto);
            }
            return lista;
        }

        public ColeccionDTO? Crear(CrearColeccionDTO datos)
        {
            UsuarioDTO? usuario = _usuarioService.ObtenerPorId(datos.UsuarioId);
            if (usuario == null)
            {
                return null;
            }

            foreach (Videojuego juego in datos.Videojuegos)
            {
                if (_videojuegoService.ObtenerPorId(juego.Id) == null)
                {
                    return null;
                }
            }

            Coleccion nueva = new Coleccion();
            nueva.Id = _idActual++;
            nueva.UsuarioId = datos.UsuarioId;
            nueva.Videojuegos = datos.Videojuegos;

            _colecciones.Add(nueva);

            ColeccionDTO dto = new ColeccionDTO();
            dto.Id = nueva.Id;
            dto.UsuarioId = nueva.UsuarioId;
            dto.Videojuegos = nueva.Videojuegos;

            return dto;
        }

        public ColeccionDTO? AgregarJuegos(CrearColeccionDTO datos)
        {
            int id = 0;
            UsuarioDTO? usuario = _usuarioService.ObtenerPorId(datos.UsuarioId);
            if (usuario == null)
            {
                return null;
            }
            else
            {
                id = usuario.ColeccionCreada.Id;
            }

            foreach (Videojuego juego in datos.Videojuegos)
            {
                if (_videojuegoService.ObtenerPorId(juego.Id) == null)
                {
                    return null;
                }
            }

            foreach (Videojuego juego in datos.Videojuegos)
            {
                if (_colecciones[id].Videojuegos.Contains(juego))
                {

                }
                else
                {
                    _colecciones[id].Videojuegos.Add(juego);
                }
            }

            ColeccionDTO dto = new ColeccionDTO();
            dto.Id = _colecciones[id].Id;
            dto.UsuarioId = _colecciones[id].UsuarioId;
            dto.Videojuegos = _colecciones[id].Videojuegos;

            return dto;
        }

        public ColeccionDTO? ObtenerPorUsuario(int usuarioId)
        {
            foreach (Coleccion c in _colecciones)
            {
                if (c.UsuarioId == usuarioId)
                {
                    ColeccionDTO dto = new ColeccionDTO();
                    dto.Id = c.Id;
                    dto.UsuarioId = c.UsuarioId;
                    dto.Videojuegos = c.Videojuegos;
                    return dto;
                }
            }
            return null;
        }

        public bool Eliminar(int id)
        {
            for (int i = 0; i < _colecciones.Count; i++)
            {
                if (_colecciones[i].Id == id)
                {
                    _colecciones.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }
    }
}