using ColeccionesVideojuegos.Models;
using ColeccionesVideojuegos.DTO;
using System.Text.Json;

namespace ColeccionesVideojuegos.Services
{
    public class VideojuegoService
    {
        private static List<Videojuego> _videojuegos = new List<Videojuego>();
        private static int _idActual = 1;

        public List<VideojuegoDTO> ObtenerTodos()
        {
            List<VideojuegoDTO> lista = new List<VideojuegoDTO>();

            foreach (Videojuego juego in _videojuegos)
            {
                VideojuegoDTO dto = new VideojuegoDTO();
                dto.Id = juego.Id;
                dto.Nombre = juego.Nombre;
                dto.Descripcion = juego.Descripcion;
                dto.Plataformas = juego.Plataformas;
                dto.ImagenUrl = juego.ImagenUrl;
                dto.CapturaUrl = juego.CapturaUrl;
                dto.FechaLanzamiento = juego.FechaLanzamiento;
                lista.Add(dto);
            }
            return lista;
        }

        public VideojuegoDTO? ObtenerPorId(int id)
        {
            foreach (Videojuego juego in _videojuegos)
            {
                if (juego.Id == id)
                {
                    VideojuegoDTO dto = new VideojuegoDTO();
                    dto.Id = juego.Id;
                    dto.Nombre = juego.Nombre;
                    dto.Descripcion = juego.Descripcion;
                    dto.Plataformas = juego.Plataformas;
                    dto.ImagenUrl = juego.ImagenUrl;
                    dto.CapturaUrl = juego.CapturaUrl;
                    dto.FechaLanzamiento = juego.FechaLanzamiento;
                    return dto;
                }
            }

            return null;
        }

        public VideojuegoDTO Crear(CrearVideojuegoDTO nuevo)
        {
            Videojuego juego = new Videojuego();
            juego.Id = _idActual++;
            juego.Nombre = nuevo.Nombre;
            juego.Descripcion = nuevo.Descripcion;
            juego.Plataformas = nuevo.Plataformas;
            juego.ImagenUrl = nuevo.ImagenUrl;
            juego.CapturaUrl = nuevo.CapturaUrl;
            juego.FechaLanzamiento = nuevo.FechaLanzamiento;

            _videojuegos.Add(juego);

            VideojuegoDTO dto = new VideojuegoDTO();
            dto.Id = juego.Id;
            dto.Nombre = juego.Nombre;
            dto.Descripcion = juego.Descripcion;
            dto.Plataformas = juego.Plataformas;
            dto.ImagenUrl = juego.ImagenUrl;
            dto.CapturaUrl = juego.CapturaUrl;
            dto.FechaLanzamiento = juego.FechaLanzamiento;

            return dto;
        }

        public bool Actualizar(int id, CrearVideojuegoDTO datos)
        {
            foreach (Videojuego juego in _videojuegos)
            {
                if (juego.Id == id)
                {
                    juego.Nombre = datos.Nombre;
                    juego.Descripcion = datos.Descripcion;
                    juego.Plataformas = datos.Plataformas;
                    juego.ImagenUrl = datos.ImagenUrl;
                    juego.CapturaUrl = datos.CapturaUrl;
                    juego.FechaLanzamiento = datos.FechaLanzamiento;
                    return true;
                }
            }

            return false;
        }

        public bool Eliminar(int id)
        {
            for (int i = 0; i < _videojuegos.Count; i++)
            {
                if (_videojuegos[i].Id == id)
                {
                    _videojuegos.RemoveAt(i);
                    return true;
                }
            }
            return false;
        }

        public bool ExisteVideojuego(int id)
        {
            foreach (Videojuego juego in _videojuegos)
            {
                if (juego.Id == id)
                {
                    return true;
                }
            }
            return false;
        }

        public List<VideojuegoDTO> JuegosPlataforma(string plataforma)
        {
            List<VideojuegoDTO> lista = new List<VideojuegoDTO>();

            foreach (Videojuego juego in _videojuegos)
            {
                for (int i = 0; i < juego.Plataformas.Count; i++)
                {
                    if (juego.Plataformas[i] == plataforma)
                    {
                        VideojuegoDTO dto = new VideojuegoDTO();
                        dto.Id = juego.Id;
                        dto.Nombre = juego.Nombre;
                        dto.Descripcion = juego.Descripcion;
                        dto.Plataformas = juego.Plataformas;
                        dto.ImagenUrl = juego.ImagenUrl;
                        dto.CapturaUrl = juego.CapturaUrl;
                        dto.FechaLanzamiento = juego.FechaLanzamiento;
                        lista.Add(dto);
                    }
                }
            }
            return lista;
        }
    }
}